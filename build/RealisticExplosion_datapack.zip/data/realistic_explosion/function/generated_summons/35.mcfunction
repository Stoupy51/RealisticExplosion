
#> realistic_explosion:generated_summons/35
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:exposed_cut_copper_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:exposed_cut_copper_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_glazed_terracotta"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:magenta_glazed_terracotta"}
execute if data storage realistic_explosion:main {id:"minecraft:orange_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:orange_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_deepslate_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_deepslate_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:purple_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:purple_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_red_sandstone_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:smooth_red_sandstone_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_copper_golem_statue"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_copper_golem_statue"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_exposed_copper_bars"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_exposed_copper_bulb"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_exposed_copper_door"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_oxidized_cut_copper"}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_chiseled_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:weathered_chiseled_copper"}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_copper_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:weathered_copper_trapdoor"}
execute if data storage realistic_explosion:main {id:"minecraft:weathered_cut_copper_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:weathered_cut_copper_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:yellow_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:yellow_stained_glass_pane"}

