
#> realistic_explosion:generated_summons/22
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:acacia_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:acacia_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:acacia_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:acacia_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:bamboo_block"}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:bamboo_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:bamboo_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:bamboo_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:big_dripleaf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:big_dripleaf"}
execute if data storage realistic_explosion:main {id:"minecraft:birch_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:birch_button"}
execute if data storage realistic_explosion:main {id:"minecraft:birch_leaves"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:birch_leaves"}
execute if data storage realistic_explosion:main {id:"minecraft:birch_planks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:birch_planks"}
execute if data storage realistic_explosion:main {id:"minecraft:birch_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:birch_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:black_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:black_banner"}
execute if data storage realistic_explosion:main {id:"minecraft:black_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:black_candle"}
execute if data storage realistic_explosion:main {id:"minecraft:black_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:black_carpet"}
execute if data storage realistic_explosion:main {id:"minecraft:brick_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:brick_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:brown_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:brown_banner"}
execute if data storage realistic_explosion:main {id:"minecraft:brown_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:brown_candle"}
execute if data storage realistic_explosion:main {id:"minecraft:brown_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:brown_carpet"}
execute if data storage realistic_explosion:main {id:"minecraft:bubble_coral"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:bubble_coral"}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cherry_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:cherry_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cherry_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:chorus_plant"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:chorus_plant"}
execute if data storage realistic_explosion:main {id:"minecraft:copper_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:copper_block"}
execute if data storage realistic_explosion:main {id:"minecraft:copper_chain"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:copper_chain"}
execute if data storage realistic_explosion:main {id:"minecraft:copper_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:copper_chest"}
execute if data storage realistic_explosion:main {id:"minecraft:copper_grate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:copper_grate"}
execute if data storage realistic_explosion:main {id:"minecraft:copper_torch"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:copper_torch"}
execute if data storage realistic_explosion:main {id:"minecraft:creeper_head"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:creeper_head"}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:crimson_door"}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:crimson_sign"}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:crimson_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:crimson_stem"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:crimson_stem"}
execute if data storage realistic_explosion:main {id:"minecraft:dark_oak_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:dark_oak_log"}
execute if data storage realistic_explosion:main {id:"minecraft:diorite_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:diorite_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:diorite_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:diorite_wall"}
execute if data storage realistic_explosion:main {id:"minecraft:firefly_bush"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:firefly_bush"}
execute if data storage realistic_explosion:main {id:"minecraft:granite_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:granite_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:granite_wall"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:granite_wall"}
execute if data storage realistic_explosion:main {id:"minecraft:green_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:green_banner"}
execute if data storage realistic_explosion:main {id:"minecraft:green_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:green_candle"}
execute if data storage realistic_explosion:main {id:"minecraft:green_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:green_carpet"}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:jungle_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:jungle_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:jungle_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:magenta_wool"}
execute if data storage realistic_explosion:main {id:"minecraft:mangrove_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:mangrove_log"}
execute if data storage realistic_explosion:main {id:"minecraft:oak_trapdoor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oak_trapdoor"}
execute if data storage realistic_explosion:main {id:"minecraft:orange_tulip"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:orange_tulip"}
execute if data storage realistic_explosion:main {id:"minecraft:pale_oak_log"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:pale_oak_log"}
execute if data storage realistic_explosion:main {id:"minecraft:poplar_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:poplar_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:poplar_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:poplar_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:powered_rail"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:powered_rail"}
execute if data storage realistic_explosion:main {id:"minecraft:purpur_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:purpur_block"}
execute if data storage realistic_explosion:main {id:"minecraft:quartz_block"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:quartz_block"}
execute if data storage realistic_explosion:main {id:"minecraft:red_concrete"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:red_concrete"}
execute if data storage realistic_explosion:main {id:"minecraft:red_mushroom"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:red_mushroom"}
execute if data storage realistic_explosion:main {id:"minecraft:redstone_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:redstone_ore"}
execute if data storage realistic_explosion:main {id:"minecraft:resin_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:resin_bricks"}
execute if data storage realistic_explosion:main {id:"minecraft:sculk_sensor"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:sculk_sensor"}
execute if data storage realistic_explosion:main {id:"minecraft:smooth_stone"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:smooth_stone"}
execute if data storage realistic_explosion:main {id:"minecraft:soul_lantern"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:soul_lantern"}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:spruce_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:spruce_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:spruce_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:stone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:stone_bricks"}
execute if data storage realistic_explosion:main {id:"minecraft:stone_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:stone_button"}
execute if data storage realistic_explosion:main {id:"minecraft:stone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:stone_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:sulfur_spike"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:sulfur_spike"}
execute if data storage realistic_explosion:main {id:"minecraft:tinted_glass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:tinted_glass"}
execute if data storage realistic_explosion:main {id:"minecraft:warped_fence"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:warped_fence"}
execute if data storage realistic_explosion:main {id:"minecraft:warped_roots"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:warped_roots"}
execute if data storage realistic_explosion:main {id:"minecraft:warped_shelf"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:warped_shelf"}
execute if data storage realistic_explosion:main {id:"minecraft:white_banner"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:white_banner"}
execute if data storage realistic_explosion:main {id:"minecraft:white_candle"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:white_candle"}
execute if data storage realistic_explosion:main {id:"minecraft:white_carpet"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:white_carpet"}

