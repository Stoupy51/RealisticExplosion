
#> realistic_explosion:generated_summons/36
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:light_blue_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:light_blue_concrete_powder"}
execute if data storage realistic_explosion:main {id:"minecraft:light_gray_concrete_powder"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:light_gray_concrete_powder"}
execute if data storage realistic_explosion:main {id:"minecraft:magenta_stained_glass_pane"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:magenta_stained_glass_pane"}
execute if data storage realistic_explosion:main {id:"minecraft:oxidized_cut_copper_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oxidized_cut_copper_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_bricks"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_blackstone_bricks"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_button"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_blackstone_button"}
execute if data storage realistic_explosion:main {id:"minecraft:polished_blackstone_stairs"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:polished_blackstone_stairs"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper_chain"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_exposed_copper_chain"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper_chest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_exposed_copper_chest"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_exposed_copper_grate"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_exposed_copper_grate"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_bars"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_oxidized_copper_bars"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_bulb"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_oxidized_copper_bulb"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_oxidized_copper_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_oxidized_copper_door"}
execute if data storage realistic_explosion:main {id:"minecraft:waxed_weathered_cut_copper"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:waxed_weathered_cut_copper"}

