
#> realistic_explosion:generated_summons/18
#
# @executed	as @e[type=item,tag=!realistic_explosion.old] & at @s
#
# @within	realistic_explosion:generated_summons/on_item
#

execute if data storage realistic_explosion:main {id:"minecraft:andesite"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:andesite"}
execute if data storage realistic_explosion:main {id:"minecraft:bee_nest"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:bee_nest"}
execute if data storage realistic_explosion:main {id:"minecraft:blue_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:blue_bed"}
execute if data storage realistic_explosion:main {id:"minecraft:blue_ice"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:blue_ice"}
execute if data storage realistic_explosion:main {id:"minecraft:campfire"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:campfire"}
execute if data storage realistic_explosion:main {id:"minecraft:cauldron"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cauldron"}
execute if data storage realistic_explosion:main {id:"minecraft:cinnabar"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cinnabar"}
execute if data storage realistic_explosion:main {id:"minecraft:coal_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:coal_ore"}
execute if data storage realistic_explosion:main {id:"minecraft:cyan_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:cyan_bed"}
execute if data storage realistic_explosion:main {id:"minecraft:farmland"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:farmland"}
execute if data storage realistic_explosion:main {id:"minecraft:gold_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:gold_ore"}
execute if data storage realistic_explosion:main {id:"minecraft:gray_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:gray_bed"}
execute if data storage realistic_explosion:main {id:"minecraft:iron_ore"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:iron_ore"}
execute if data storage realistic_explosion:main {id:"minecraft:lily_pad"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:lily_pad"}
execute if data storage realistic_explosion:main {id:"minecraft:lime_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:lime_bed"}
execute if data storage realistic_explosion:main {id:"minecraft:mycelium"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:mycelium"}
execute if data storage realistic_explosion:main {id:"minecraft:oak_door"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oak_door"}
execute if data storage realistic_explosion:main {id:"minecraft:oak_sign"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oak_sign"}
execute if data storage realistic_explosion:main {id:"minecraft:oak_slab"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oak_slab"}
execute if data storage realistic_explosion:main {id:"minecraft:oak_wood"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:oak_wood"}
execute if data storage realistic_explosion:main {id:"minecraft:observer"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:observer"}
execute if data storage realistic_explosion:main {id:"minecraft:obsidian"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:obsidian"}
execute if data storage realistic_explosion:main {id:"minecraft:pink_bed"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:pink_bed"}
execute if data storage realistic_explosion:main {id:"minecraft:red_sand"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:red_sand"}
execute if data storage realistic_explosion:main {id:"minecraft:red_wool"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:red_wool"}
execute if data storage realistic_explosion:main {id:"minecraft:repeater"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:repeater"}
execute if data storage realistic_explosion:main {id:"minecraft:seagrass"} run summon falling_block ~ ~ ~ {Tags:["realistic_explosion.new"],DropItem:0b,BlockState:"minecraft:seagrass"}

